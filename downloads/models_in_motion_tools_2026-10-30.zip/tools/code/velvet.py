"""VELVET - the opposite of ASPERO. Stack the takes instead of cutting between them.

Every frame is the average of the same frame in all the takes. Where the takes agree
the picture stays sharp; where they disagree it goes soft and ghosts. The difference
between the takes stops being a number and becomes the picture.

Drag a folder of takes onto VELVET.bat. Recipe: velvet.txt in that folder.
"""
from common import *
import patterns

DEFAULT = """\
# VELVET recipe. One recipe = one stack. Separate several with a line of ---
# name:     your word for this one
# mode:     mean     all takes averaged: soft, ghosting, noise cancels
#           median   the middle value: outliers vanish, the consensus survives sharp
#           ramp     starts as one take, becomes the average of all by the end
#           trail    the average, plus a smear of the frames before (motion leaves a wake)
#           breathe  mostly the average; on the pattern's hits it collapses to ONE take, then swells back
#           quantum  the material decides: one take where the takes disagree, all where they agree
# pattern:  for breathe: where it collapses (same words as ASPERO: tresillo, fib, euclid 3 8 ...)
# step:     frames per step of the pattern
# attack:   breathe: frames to collapse        release: frames to swell back
# invert:   quantum: yes = collapse where they AGREE instead

name: mean
mode: mean
---
name: breathe
mode: breathe
pattern: tresillo
step: 7
attack: 3
release: 14
"""
KEYS = {"name", "mode", "pattern", "step", "attack", "release", "invert"}


def depth_curve(r, clips, n):
    """How many takes are stacked at each frame, as 0..1 (0 = one take, 1 = all of them)."""
    mode = r.get("mode", "mean").lower()
    if mode == "ramp":
        return np.linspace(0, 1, n)
    if mode == "breathe":
        d = np.ones(n)
        attack, release = number(r, "attack", 3), number(r, "release", 14)
        for p in patterns.positions(r.get("pattern", "tresillo"), n, number(r, "step", 7.0)):
            for k in range(attack):                       # fall to one take
                if 0 <= p - attack + k < n:
                    d[p - attack + k] = min(d[p - attack + k], k / attack)
            for k in range(release):                      # swell back to all
                if p + k < n:
                    d[p + k] = min(d[p + k], k / release)
        return d
    if mode == "quantum":
        small = [[cv2.resize(f, (160, 90)).astype(np.float32) for f in c[:n]] for c in clips]
        div = np.array([np.mean([np.abs(c[i] - small[0][i]).mean() for c in small[1:]]) for i in range(n)])
        div = np.convolve(div, np.ones(5) / 5, mode="same")
        lo, hi = np.percentile(div, 5), np.percentile(div, 95)
        norm = np.clip((div - lo) / max(hi - lo, 1e-6), 0, 1)
        return norm if r.get("invert", "no").lower() == "yes" else 1 - norm
    return np.ones(n)


def make(folder, takes, r, index):
    w, h, fps = same_size(takes)
    clips = [read_all(t) for t in takes]
    n = min(len(c) for c in clips)
    mode = r.get("mode", "mean").lower()
    depth = depth_curve(r, clips, n)

    out = out_path(folder, "velvet", index, r.get("name", mode))
    trail = None
    with Writer(out, w, h, fps, sound=takes[0]) as video:
        for f in range(n):
            stack = np.stack([c[f] for c in clips]).astype(np.float32)
            if mode == "median":
                img = np.median(stack, axis=0)
            else:
                k = 1 + int(round((len(clips) - 1) * float(depth[f])))   # how many takes
                img = stack[:k].mean(axis=0)
            if mode == "trail":
                trail = img if trail is None else trail * 0.72 + img * 0.28
                img = trail
            video.write(img)

    print(f"[{r.get('name', mode)}] {mode}, {len(takes)} takes, mean depth {depth.mean():.2f}")
    record(out, r, [f"{len(takes)} takes stacked, base {takes[0].name}",
                    f"average share of takes in the stack: {depth.mean():.2f}"])
    return out


def main():
    folder = target_folder()
    takes = find_takes(folder)
    print(f"{folder}\n{len(takes)} takes")
    if len(takes) < 2:
        raise SystemExit("VELVET needs at least 2 takes of the same shot")
    for i, r in enumerate(recipes(folder, "velvet.txt", DEFAULT, KEYS), 1):
        make(folder, takes, r, i)
    return folder / "velvet"


run(main)
