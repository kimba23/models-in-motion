"""RUN - plays every script in a folder of takes, then opens INDEX.

The scripts can come from anywhere: the kit, a classmate, a chat. RUN only
asks that they are .py files sitting in the folder of takes. Afterwards it
makes every new video playable in the browser (chats usually write mp4v,
which browsers refuse), and writes index.html: every video, with its name.

Double-click RUN.bat in the folder: every .py there runs.
Drag one .py onto RUN.bat: only that one runs.
"""
import subprocess
import sys
import time
from pathlib import Path
import imageio_ffmpeg

KIT = Path(__file__).resolve().parents[2]
PYTHON = Path(sys.executable)
VIDEO = {".mp4", ".avi", ".mov", ".mkv", ".webm"}


def playable(video):
    """Re-encode to H.264 mp4, the one format every browser plays."""
    ffmpeg = imageio_ffmpeg.get_ffmpeg_exe()
    out = video.with_suffix(".mp4")
    tmp = video.with_name(video.stem + ".__tmp.mp4")
    r = subprocess.run([ffmpeg, "-y", "-loglevel", "error", "-i", str(video), "-c:v", "libx264",
                        "-pix_fmt", "yuv420p", "-crf", "18", "-c:a", "aac", str(tmp)])
    if r.returncode or not tmp.exists():
        print(f"   could not convert {video.name}")
        return
    if video != out:
        video.unlink()
    tmp.replace(out)


def main():
    arg = Path(sys.argv[1]) if len(sys.argv) > 1 else Path.cwd()
    folder = arg.parent if arg.is_file() else arg
    scripts = [arg] if arg.suffix.lower() == ".py" else sorted(folder.glob("*.py"))
    if not scripts:
        print(f"No .py files in {folder}")
        print("Save a script from the chat into this folder (as name.py, not name.py.txt).")
        return
    for s in folder.glob("*.py.txt"):
        print(f"! {s.name} is a text file: rename it to {s.name[:-4]} so it can run")

    started = time.time() - 1
    for script in scripts:
        print(f"\n=== {script.name} ===", flush=True)
        r = subprocess.run([str(PYTHON), "-s", str(script)], cwd=str(folder))
        if r.returncode:
            print(f"\n{script.name} STOPPED WITH AN ERROR.")
            print("Copy everything above, paste it to the chat, and ask it to fix the script.")

    new = [p for p in folder.rglob("*") if p.suffix.lower() in VIDEO and p.parent != folder
           and p.stat().st_mtime >= started and ".__tmp" not in p.name]
    if new:
        print(f"\nmaking {len(new)} new video(s) playable in the browser ...", flush=True)
        for v in new:
            playable(v)

    subprocess.run([str(PYTHON), "-s", str(KIT / "tools" / "code" / "index.py"), str(folder)])


main()
