"""MELT - dissolve a video the way Deforum did. This one uses diffusion (the GPU).

LTX cannot melt: it makes clean chunks of motion. So the melt happens afterwards.
Every frame is redrawn by a small image model (sd-turbo, image-to-image), and before
it is redrawn it is MIXED with the previous redrawn frame:

    frame_in  = source * (1 - feedback) + previous_output * feedback
    frame_out = redraw(frame_in, strength, prompt)

Because the last output feeds the next one, the picture never resets: it drifts and
dissolves continuously. A good use: MICRO-EDIT first, then MELT the cut.

Drag a video (or a folder of videos) onto MELT.bat. Recipe: melt.txt beside it.
Close ComfyUI first: both want the GPU.
"""
from common import *

MODEL = Path(__file__).resolve().parents[2] / "ComfyUI" / "models" / "melt" / "sd-turbo"

DEFAULT = """\
# MELT recipe. One recipe = one melt. Separate several with a line of ---
# name:      your word for this one
# prompt:    describe what is IN the video (the subject, the light). A wrong prompt looks absurd.
# strength:  how much each frame is redrawn. 0.25 barely, 0.42 photographic, 0.58 starts inventing
# feedback:  how much of the last output flows into the next frame. 0 = flicker, 0.6-0.75 = melt,
#            above 0.9 it runs away into abstraction
# detail:    how much of the source's own texture comes back (0-1). 0.85 keeps it photographic
# seed:      another number = another melt
# frames:    only the first N frames (0 = all). Use 48 to try a setting quickly.

name: melt
prompt: a dim subway car at night, passengers in winter coats, film grain, natural light
strength: 0.42
feedback: 0.7
detail: 0.85
seed: 0
frames: 0
"""
KEYS = {"name", "prompt", "strength", "feedback", "detail", "seed", "frames"}

_pipe = None


def model():
    """Load sd-turbo once (from inside the kit, no internet)."""
    global _pipe
    if _pipe is None:
        os.environ.setdefault("TRANSFORMERS_VERBOSITY", "error")   # hide the libraries' warnings
        import torch
        import diffusers
        from diffusers import AutoPipelineForImage2Image
        diffusers.utils.logging.set_verbosity_error()
        diffusers.utils.logging.disable_progress_bar()
        print("loading the melt model (sd-turbo) ...")
        _pipe = AutoPipelineForImage2Image.from_pretrained(str(MODEL), torch_dtype=torch.float16,
                                                           safety_checker=None, local_files_only=True)
        _pipe = _pipe.to("cuda")
        _pipe.set_progress_bar_config(disable=True)
    return _pipe


def make(folder, video, r, index):
    import torch
    from PIL import Image
    pipe = model()
    w, h, fps, n = info(video)
    W, H = w - w % 8, h - h % 8                          # the model wants multiples of 8
    strength, feedback = number(r, "strength", 0.42), number(r, "feedback", 0.7)
    detail = number(r, "detail", 0.85)
    limit = number(r, "frames", 0) or n
    steps = max(4, int(np.ceil(1.0 / strength)) + 1)     # turbo needs strength * steps >= 1
    gen = torch.Generator("cuda").manual_seed(number(r, "seed", 0))

    out = out_path(folder, "melt", index, r.get("name", "melt"))
    cap, prev = cv2.VideoCapture(str(video)), None
    with Writer(out, W, H, fps, sound=video) as writer:
        for i in range(limit):
            ok, fr = cap.read()
            if not ok:
                break
            src = cv2.cvtColor(cv2.resize(fr, (W, H)), cv2.COLOR_BGR2RGB).astype(np.float32) / 255
            inp = src if prev is None else src * (1 - feedback) + prev * feedback     # the loop
            img = pipe(prompt=r.get("prompt", ""), image=Image.fromarray((inp * 255).astype(np.uint8)),
                       strength=strength, guidance_scale=0.0, num_inference_steps=steps,
                       generator=gen).images[0]
            res = np.asarray(img).astype(np.float32) / 255
            if detail > 0:                                 # put the source's own texture back
                res = cv2.GaussianBlur(res, (0, 0), 5.5) + (src - cv2.GaussianBlur(src, (0, 0), 5.5)) * detail
            prev = np.clip(res, 0, 1)
            writer.write(cv2.cvtColor((prev * 255).astype(np.uint8), cv2.COLOR_RGB2BGR))
            print(f"  {i + 1}/{limit}", end="\r", flush=True)
    cap.release()
    print(f"\n[{r.get('name', 'melt')}] {video.name}, strength {strength}, feedback {feedback}")
    record(out, r, [f"melted from {video.name}, {limit} frames, {steps} steps per frame, model sd-turbo"])
    return out


def main():
    t = target_folder()
    folder = t.parent if t.is_file() else t
    videos = [t] if t.is_file() else find_takes(folder)
    print(f"{folder}\nmelting: " + ", ".join(v.name for v in videos))
    if len(videos) > 1:
        print(f"\nThis melts ALL {len(videos)} videos, about a minute each (more if ComfyUI is open).")
        print("To melt just one, drag that one video onto MELT.bat.\n")
    for i, r in enumerate(recipes(folder, "melt.txt", DEFAULT, KEYS), 1):
        for v in videos:
            make(folder, v, r, i)
    return folder / "melt"


run(main)
