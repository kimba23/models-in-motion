"""MICRO-EDIT - aspero. Cut between many takes of one shot, a few frames at a time.

The base take plays. On the frames a pattern picks, a frame from ANOTHER take
replaces it. Same shot, same light, different performance: the cut is a flinch.

Drag a folder of takes onto MICRO-EDIT.bat. Recipe: micro-edit.txt in that folder.
"""
import random
from common import *
import patterns

DEFAULT = """\
# MICRO-EDIT recipe. One recipe = one cut. Separate several with a line of ---
# name:     your word for this cut
# pattern:  where the cuts land. fib | revfib | tresillo | cinquillo | habanera | son | rumba
#           bossa | shiko | gahu | fourfloor | backbeat | euclid 5 16 | even 12 | phi 11
#           prime | list 12 30 45 | steps x..x.x..   (see code\\patterns.py)
# step:     frames per step of a rhythm (6 = 4 steps a second at 24 fps)
# length:   frames each cut lasts (1 = one frame)
# pick:     which take fills each cut: random | cycle (in order)
# window:   only cut between these seconds, e.g. 2 5   (the dose)
# seed:     another number = other random picks

name: gesture
pattern: fib
length: 1
pick: random
seed: 0
---
name: tresillo
pattern: tresillo
step: 6
length: 1
pick: cycle
"""
KEYS = {"name", "pattern", "step", "length", "pick", "window", "seed"}


def make(folder, takes, r, index):
    w, h, fps = same_size(takes)
    clips = [read_all(t) for t in takes]                 # every frame of every take
    n = min(len(c) for c in clips)

    hits = patterns.positions(r.get("pattern", "fib"), n, number(r, "step", 6.0))
    if "window" in r:
        a, b = (float(x) for x in r["window"].split()[:2])
        hits = [p for p in hits if a * fps <= p < b * fps]

    rnd = random.Random(number(r, "seed", 0))
    length = number(r, "length", 1)
    source = [0] * n                                     # which take each frame comes from
    for i, p in enumerate(hits):
        take = rnd.randrange(1, len(takes)) if r.get("pick", "random") == "random" else 1 + i % (len(takes) - 1)
        for f in range(p, min(p + length, n)):
            source[f] = take

    out = out_path(folder, "cuts", index, r.get("name", "cut"))
    with Writer(out, w, h, fps, sound=takes[0]) as video:
        for f in range(n):
            video.write(clips[source[f]][f])

    changed = sum(1 for s in source if s)
    print(f"[{r.get('name', 'cut')}] {len(hits)} cuts, {changed} of {n} frames from other takes ({100 * changed // n}%)")
    record(out, r, [f"base {takes[0].name}, {len(takes)} takes, {changed}/{n} frames from other takes",
                    "frame  second  take"] + [f"{p:5d}  {p / fps:6.2f}  {takes[source[p]].name}" for p in hits])
    return out


def main():
    folder = target_folder()
    takes = find_takes(folder)
    print(f"{folder}\n{len(takes)} takes, base = {takes[0].name}")
    if len(takes) < 2:
        raise SystemExit("MICRO-EDIT needs at least 2 takes of the same shot")
    for i, r in enumerate(recipes(folder, "micro-edit.txt", DEFAULT, KEYS), 1):
        make(folder, takes, r, i)
    return folder / "cuts"


run(main)
