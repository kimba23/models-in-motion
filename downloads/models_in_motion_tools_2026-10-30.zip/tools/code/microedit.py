"""Old name of ASPERO (aspero.py). Kept so copies of MICRO-EDIT.bat still work."""
import runpy
from pathlib import Path

runpy.run_path(str(Path(__file__).with_name("aspero.py")), run_name="__main__")
