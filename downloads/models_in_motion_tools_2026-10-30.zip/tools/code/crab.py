"""CRAB - the crab walk. N frames forward, M frames back, again and again.

Nothing new is made: every frame on screen is a real frame of the take.
Only the ORDER is synthetic. The shot keeps advancing but flinches backwards.
It works best on water (a wave that cannot decide). On a gesture it reads as undoing.

With several takes in the folder you can make a crab SALAD: the steps back land in
another take, the right moment of a performance that never happened.

Drag a folder onto CRAB.bat (one take is enough). Recipe: crab.txt in that folder.
"""
from common import *

DEFAULT = """\
# CRAB recipe. One recipe = one walk. Separate several with a line of ---
# name:     your word for this walk
# forward:  frames forward each time
# back:     frames back each time (must be smaller than forward)
# from:     head (start at the beginning) | tail (walk backwards through the shot)
# take:     which take walks (file name; default the first)
# salad:    no | back (the steps back come from other takes) | every (a different take every frame)
# cycles:   stop after this many forward+back steps (0 = until the end)

name: crab
forward: 3
back: 1
from: head
salad: no
---
name: salad
forward: 3
back: 1
salad: back
"""
KEYS = {"name", "forward", "back", "from", "take", "salad", "cycles"}


def walk(n, forward, back, tail, cycles):
    """The list of frame numbers to show, in order."""
    if forward <= back:
        raise SystemExit("forward must be bigger than back, or the crab never arrives")
    d = -1 if tail else 1
    moves = [d] * forward + [-d] * back
    p, order, i = (n - 1 if tail else 0), [], 0
    while 0 <= p < n:
        order.append(p)
        p += moves[i % len(moves)]
        i += 1
        if cycles and i >= cycles * len(moves):
            break
    return order


def make(folder, takes, r, index):
    if r.get("take"):
        first = [t for t in takes if r["take"].lower() in t.name.lower()]
        if not first:
            raise SystemExit(f"no take called '{r['take']}'")
        takes = first[:1] + [t for t in takes if t != first[0]]
    salad = r.get("salad", "no").lower()
    if salad == "no":
        takes = takes[:1]
    w, h, fps = same_size(takes)
    clips = [read_all(t) for t in takes]
    n = min(len(c) for c in clips)

    order = walk(n, number(r, "forward", 3), number(r, "back", 1),
                 r.get("from", "head").lower() == "tail", number(r, "cycles", 0))

    # which take each shown frame comes from
    source, steps_back = [], 0
    for k, f in enumerate(order):
        going_back = k > 0 and (f < order[k - 1]) != (r.get("from", "head").lower() == "tail")
        if salad == "every" and len(takes) > 1:
            source.append(k % len(takes))
        elif salad == "back" and len(takes) > 1 and going_back:
            steps_back += 1
            source.append(1 + steps_back % (len(takes) - 1))
        else:
            source.append(0)

    out = out_path(folder, "crab", index, r.get("name", "crab"))
    with Writer(out, w, h, fps) as video:              # silent: sound cannot walk like this
        for f, s in zip(order, source):
            video.write(clips[s][f])

    print(f"[{r.get('name', 'crab')}] {len(order)} frames shown from {n} ({len(order) / fps:.1f} s), "
          f"{len(takes)} take(s)")
    record(out, r, [f"take {takes[0].name}" + (f" + {len(takes) - 1} for the salad" if len(takes) > 1 else ""),
                    f"{n} source frames became {len(order)} frames",
                    "order: " + " ".join(str(f) for f in order[:60]) + (" ..." if len(order) > 60 else "")])
    return out


def main():
    folder = target_folder()
    takes = find_takes(folder)
    print(f"{folder}\n{len(takes)} take(s), walking {takes[0].name}")
    for i, r in enumerate(recipes(folder, "crab.txt", DEFAULT, KEYS), 1):
        make(folder, takes, r, i)
    return folder / "crab"


run(main)
