"""patterns.py - where things happen in time. Each function returns a list of frame numbers.

Two families:
  an ARC   (fib, revfib)  never repeats; dense then calm. Reads as a gesture.
  a PULSE  (everything else) repeats or almost repeats. Reads as a state, a groove.

In a recipe you write:   pattern: tresillo     or   pattern: euclid 5 16   or   pattern: list 12 30 45
step: is how many frames one step of a rhythm lasts (6 = 4 steps a second at 24 fps).
"""

# Rhythms written as steps: x = hit, . = rest. Add your own here, with a name.
RHYTHMS = {
    "tresillo":  "x..x..x.",                  # Cuba / the 3-3-2 under almost everything
    "cinquillo": "x.xx.xx.",
    "habanera":  "x..xx.x.",
    "son":       "x..x..x...x.x...",          # son clave 3-2
    "rumba":     "x..x...x..x.x...",          # rumba clave 3-2
    "bossa":     "x..x..x...x..x..",
    "shiko":     "x...x.x...x.x...",
    "gahu":      "x..x..x...x...x.",
    "fourfloor": "x...x...x...x...",
    "backbeat":  "....x.......x...",
}


def fib(limit):
    """1 2 3 5 8 13 21 34 55 89 ... below limit."""
    out, a, b = [], 1, 2
    while a < limit:
        out.append(a)
        a, b = b, a + b
    return out


def euclid(k, n):
    """k hits spread as evenly as possible over n steps (Bjorklund). euclid(3, 8) is the tresillo."""
    if k <= 0:
        return "." * n
    if k >= n:
        return "x" * n
    a, b = [["x"] for _ in range(k)], [["."] for _ in range(n - k)]
    while len(b) > 1:
        m = min(len(a), len(b))
        a, b = [a[i] + b[i] for i in range(m)], (a[m:] or b[m:])
    return "".join(s for g in a + b for s in g)


def tile(steps, limit, step_frames):
    """Repeat a step string like 'x..x..x.' across the clip; return the frames of the hits."""
    out, i = [], 0
    while True:
        f = int(round(i * step_frames))
        if f >= limit:
            return out
        if steps[i % len(steps)] == "x":
            out.append(f)
        i += 1


def golden(k, limit):
    """k positions spaced by the golden ratio: spread out, never repeating."""
    g = (5 ** 0.5 - 1) / 2
    return sorted({int(((i * g) % 1.0) * limit) for i in range(1, k + 1)})


def primes(limit):
    return [p for p in range(2, limit) if all(p % d for d in range(2, int(p ** 0.5) + 1))]


def positions(spec, limit, step_frames=6.0):
    """'tresillo' / 'euclid 5 16' / 'fib' / 'list 3 9 27' ... -> sorted frame numbers below limit."""
    words = spec.replace(",", " ").replace(":", " ").split() or ["fib"]
    kind, args = words[0].lower(), words[1:]
    if kind in RHYTHMS:
        out = tile(RHYTHMS[kind], limit, step_frames)
    elif kind == "steps":                      # your own: steps x..x.x..
        out = tile(args[0], limit, step_frames)
    elif kind == "fib":
        out = fib(limit)
    elif kind == "revfib":
        out = [limit - 1 - p for p in fib(limit)]
    elif kind == "euclid":
        out = tile(euclid(int(args[0]), int(args[1])), limit, step_frames)
    elif kind == "even":
        out = list(range(0, limit, int(args[0])))
    elif kind in ("phi", "golden"):
        out = golden(int(args[0]) if args else 11, limit)
    elif kind == "prime":
        out = primes(limit)
    elif kind == "list":
        out = [int(a) for a in args]
    else:
        names = ", ".join(list(RHYTHMS) + ["steps x..x.", "fib", "revfib", "euclid k n", "even n", "phi k", "prime", "list ..."])
        raise SystemExit(f"unknown pattern '{spec}'. Known: {names}")
    return sorted({p for p in out if 0 <= p < limit})
