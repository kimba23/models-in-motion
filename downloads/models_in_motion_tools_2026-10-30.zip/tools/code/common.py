"""common.py - the parts every tool shares. Read this first.

A tool here is a small Python file that:
  1. finds the takes (videos) in a folder,
  2. reads a recipe (a .txt of "key: value" lines) from that folder,
  3. makes new frames out of the old ones,
  4. writes a video + a .txt record of what it did.

Frames are numpy arrays (height x width x 3, BGR colour, values 0-255).
That is all a picture is here: a grid of numbers you can copy, mix or reorder.
"""
import os
import re
import subprocess
import sys
from pathlib import Path

import cv2                # reads video frames
import imageio_ffmpeg     # carries its own ffmpeg, so nothing has to be installed
import numpy as np

for _s in (sys.stdout, sys.stderr):
    if hasattr(_s, "reconfigure"):
        _s.reconfigure(encoding="utf-8", errors="replace")

FFMPEG = imageio_ffmpeg.get_ffmpeg_exe()
VIDEO = {".mp4", ".mov", ".webm", ".mkv"}


# ---- finding things -------------------------------------------------------

def target_folder():
    """The folder (or file) that was dragged onto the .bat."""
    if len(sys.argv) < 2:
        raise SystemExit("Drag a folder of takes (or a video) onto the .bat file.")
    t = Path(sys.argv[1].strip('"'))
    if not t.exists():
        raise SystemExit(f"not found: {t}")
    return t


def find_takes(folder):
    """All videos directly inside the folder, sorted by name. The first is the BASE."""
    takes = sorted(p for p in folder.iterdir() if p.suffix.lower() in VIDEO)
    if not takes:
        raise SystemExit(f"no videos in {folder}")
    return takes


def info(path):
    """(width, height, fps, frame count) of a video."""
    cap = cv2.VideoCapture(str(path))
    if not cap.isOpened():
        raise SystemExit(f"cannot open {path.name}")
    w, h = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)), int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps, n = cap.get(cv2.CAP_PROP_FPS) or 24.0, int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    cap.release()
    return w, h, fps, n


def same_size(takes):
    """Stop if the takes are not all the same size (they must be one shot)."""
    w, h, fps, _ = info(takes[0])
    bad = [t.name for t in takes if info(t)[:2] != (w, h)]
    if bad:
        raise SystemExit(f"not the same size as {takes[0].name}: {', '.join(bad)}")
    return w, h, fps


def read_all(path, size=None):
    """Every frame of a video, as a list. Fine for short takes (a few seconds)."""
    cap, frames = cv2.VideoCapture(str(path)), []
    while True:
        ok, f = cap.read()
        if not ok:
            break
        frames.append(cv2.resize(f, size) if size else f)
    cap.release()
    return frames


# ---- recipes ---------------------------------------------------------------

def recipes(folder, filename, default_text, keys):
    """Read <folder>/<filename>. Several recipes are separated by a line of ---.
    If the file is missing, write the default (with its notes) and use it."""
    path = folder / filename
    if not path.exists():
        path.write_text(default_text, encoding="utf-8")
        print(f"No {filename} here, so I wrote an example one. Open it to change it.")
    out = []
    for block in re.split(r"^\s*-{3,}\s*$", path.read_text(encoding="utf-8", errors="replace"), flags=re.M):
        r = {}
        for line in block.splitlines():
            line = line.split("#", 1)[0].strip()          # # starts a note
            if ":" not in line:
                continue
            k, v = (x.strip() for x in line.split(":", 1))
            if k.lower() in keys:
                r[k.lower()] = v
            else:
                print(f"  (ignoring unknown line '{k}: {v}')")
        if r:
            out.append(r)
    if not out:
        raise SystemExit(f"{filename} has no recipe in it")
    return out


def number(r, key, default):
    """A number from a recipe, or the default."""
    try:
        return type(default)(float(r.get(key, default)))
    except ValueError:
        raise SystemExit(f"'{key}: {r[key]}' should be a number")


# ---- writing ---------------------------------------------------------------

def out_path(folder, sub, index, name):
    """<folder>/<sub>/NN_name.mp4, never overwriting an older one."""
    d = folder / sub
    d.mkdir(exist_ok=True)
    name = re.sub(r"[^\w\-]+", "_", name).strip("_") or "cut"
    p, k = d / f"{index:02d}_{name}.mp4", 2
    while p.exists():
        p, k = d / f"{index:02d}_{name}_v{k}.mp4", k + 1
    return p


def has_audio(path):
    r = subprocess.run([FFMPEG, "-hide_banner", "-i", str(path)], capture_output=True,
                       text=True, encoding="utf-8", errors="replace")
    return "Audio:" in r.stderr


class Writer:
    """Write frames one by one into an mp4. Optionally take the sound from another video.

        with Writer(path, w, h, fps, sound=take) as out:
            out.write(frame)
    """
    def __init__(self, path, w, h, fps, sound=None):
        cmd = [FFMPEG, "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "bgr24",
               "-s", f"{w}x{h}", "-r", f"{fps}", "-i", "-"]
        if sound and has_audio(sound):
            cmd += ["-i", str(sound), "-map", "0:v", "-map", "1:a", "-c:a", "aac", "-b:a", "192k", "-shortest"]
        cmd += ["-c:v", "libx264", "-crf", "16", "-preset", "medium", "-pix_fmt", "yuv420p", str(path)]
        self.p = subprocess.Popen(cmd, stdin=subprocess.PIPE)
        self.size = (w, h)

    def write(self, frame):
        frame = np.clip(frame, 0, 255).astype(np.uint8)
        if frame.shape[1::-1] != self.size:
            frame = cv2.resize(frame, self.size)
        self.p.stdin.write(np.ascontiguousarray(frame).tobytes())

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.p.stdin.close()
        self.p.wait()


def record(video, recipe, notes):
    """Save the recipe + notes beside the video, so anyone can see how it was made."""
    lines = [f"{k}: {v}" for k, v in recipe.items()] + [""] + [f"# {n}" for n in notes]
    video.with_suffix(".txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"  -> {video.parent.name}\\{video.name}")


def run(main):
    """Run a tool's main(), show a plain message if it stops, open the results."""
    try:
        opened = main()
        print("\nDone.")
        if opened:
            os.startfile(opened)
    except SystemExit as e:
        if e.code not in (None, 0):
            print(f"\nSTOPPED: {e.code}")
