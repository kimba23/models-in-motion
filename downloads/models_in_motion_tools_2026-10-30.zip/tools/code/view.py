"""VIEW - see everything in a folder at once: takes, cuts, crabs, velvets, melts.

Drag a folder onto VIEW.bat (or copy VIEW.bat into the folder and double-click it).
It writes view.html into that folder and opens it. Two ways to look:

  GRID  every video and picture, playing, grouped by subfolder, each with its recipe.
  PAGE  your study: the text of study.txt flowing around the videos while they play.
        A line "@ cuts/01_gesture.mp4" in study.txt puts that video there in the text.
        Drag a video to move it, drag its corner to resize it: the text gets out of the way.
        PULSE makes the text jolt on a rhythm: "from the cut" follows the frames where a
        ASPERO result cuts (read from its .txt), or pick tresillo, son, fib ...
        A line "pulse: tresillo" (or "pulse: cut") in study.txt chooses it from the start.
        (The text layout is done by Pretext, github.com/chenglou/pretext, MIT license.)

Paths are relative, so the folder can be copied anywhere and view.html still works.
Run VIEW again after new results or after editing study.txt.
"""
import json
import webbrowser
from common import *

MEDIA = {".mp4": "video", ".mov": "video", ".webm": "video",
         ".png": "image", ".jpg": "image", ".jpeg": "image", ".webp": "image"}

STUDY = """\
# {title}

This is your study page. Write here what you did and what you saw. Each blank line
starts a new paragraph. A line starting with # is a heading.

A line that starts with @ puts a video (or a picture) at that point, and the text flows
around it while it plays. On the page you can drag any video somewhere else, or drag its
corner to make it bigger: the text moves out of the way.

{lines}

Write as much as you want: the more text, the more there is to flow around the pictures.
The words are part of the work. Name your operations, describe the accident, keep the
detalles.
"""


def scan(folder):
    """Every media file under the folder, grouped by subfolder, with its recipe text."""
    sections = {}
    for p in sorted(folder.rglob("*")):
        kind = MEDIA.get(p.suffix.lower())
        if not kind or any(part.startswith(".") for part in p.relative_to(folder).parts):
            continue
        rel = p.relative_to(folder)
        group = str(rel.parent).replace("\\", "/") if rel.parent != Path(".") else "takes"
        txt = p.with_suffix(".txt")
        sections.setdefault(group, []).append({
            "src": rel.as_posix(), "kind": kind, "name": p.name,
            "recipe": txt.read_text(encoding="utf-8", errors="replace") if txt.exists() else ""})
    order = sorted(sections, key=lambda g: (g != "takes", g))
    return [{"name": g, "items": sections[g]} for g in order]


def starter(folder, sections):
    """A first study.txt: the first take, then the first result of every group."""
    picks = [s["items"][0]["src"] for s in sections][:5]
    lines = []
    for i, src in enumerate(picks):
        lines.append(f"@ {src}")
        lines.append("" if i == len(picks) - 1 else
                     "Say something about this one here, and the text will wrap around it.\n")
    return STUDY.format(title=folder.name, lines="\n".join(lines))


def main():
    t = target_folder()
    folder = t.parent if t.is_file() else t
    sections = scan(folder)
    study = folder / "study.txt"
    if not study.exists():
        study.write_text(starter(folder, sections), encoding="utf-8")
        print("No study.txt here, so I wrote a first one. Open it and write your own text.")
    import patterns                                 # the same named rhythms as the tools
    data = {"title": folder.name, "sections": sections,
            "study": study.read_text(encoding="utf-8", errors="replace"),
            "rhythms": patterns.RHYTHMS}
    code = Path(__file__).parent
    page = (code / "view_template.html").read_text(encoding="utf-8")
    page = page.replace("/*PRETEXT*/", (code / "pretext.js").read_text(encoding="utf-8"))
    page = page.replace("/*DATA*/null", json.dumps(data, ensure_ascii=False).replace("</", "<\\/"))
    out = folder / "view.html"
    out.write_text(page, encoding="utf-8")
    n = sum(len(s["items"]) for s in sections)
    print(f"{folder}\n{n} files in {len(sections)} groups -> view.html")
    webbrowser.open(out.as_uri())


run(main)
