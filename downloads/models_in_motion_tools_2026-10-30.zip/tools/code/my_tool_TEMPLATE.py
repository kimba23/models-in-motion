"""MY TOOL - copy this file to make your own tool. This one does something simple on
purpose: it plays the base take, but on the pattern's hits it shows the frame
from the END of the shot instead (a glimpse of where the shot is going).

To make your own:
  1. Copy this file and rename it, e.g. code\\echo.py
  2. Copy MY-TOOL.bat, rename it ECHO.bat, and change the file name inside it to echo.py
  3. Change the recipe (DEFAULT, KEYS) and the middle of make(): that is your idea.
  4. Drag a folder of takes onto your .bat.

You can paste this whole file into Claude or ChatGPT in the browser and say:
"Change make() so that ... (your idea)". Paste the answer back here, save, drag again.
If it stops with an error, paste the error to the chat too.

What you have to work with (from common.py):
  takes                  the videos in the folder, sorted by name (takes[0] = the base)
  read_all(take)         every frame of a take, as a list of pictures
  a picture              a numpy array: height x width x 3 (blue, green, red), 0-255
  patterns.positions()   frame numbers from a rhythm name (tresillo, fib, euclid 5 16 ...)
  Writer(...)            writes pictures one by one into an mp4
  record(...)            saves the recipe + your notes beside the video
"""
from common import *
import patterns

DEFAULT = """\
# MY TOOL recipe. One recipe = one video. Separate several with a line of ---
name: glimpse
pattern: fib
"""
KEYS = {"name", "pattern", "step"}


def make(folder, takes, r, index):
    w, h, fps = same_size(takes)
    frames = read_all(takes[0])                       # the base take
    n = len(frames)
    hits = patterns.positions(r.get("pattern", "fib"), n, number(r, "step", 6.0))

    out = out_path(folder, "my_tool", index, r.get("name", "mine"))
    with Writer(out, w, h, fps, sound=takes[0]) as video:
        for f in range(n):
            # ---- your idea goes here: decide which picture to show at frame f ----
            if f in hits:
                picture = frames[n - 1 - f]          # a frame from the other end of the shot
            else:
                picture = frames[f]
            # -----------------------------------------------------------------------
            video.write(picture)

    record(out, r, [f"{len(hits)} glimpses in {n} frames of {takes[0].name}"])
    return out


def main():
    folder = target_folder()
    takes = find_takes(folder)
    for i, r in enumerate(recipes(folder, "my-tool.txt", DEFAULT, KEYS), 1):
        make(folder, takes, r, i)
    return folder / "my_tool"


run(main)
