TOOLS
=====

HOW IT WORKS
  1. A folder with the takes of ONE shot (the .mp4 files).
  2. Copy into it: RUN.bat, and the scripts you want from scripts\.
  3. Double-click RUN.bat. Every .py in the folder runs; each puts its result
     in a subfolder with its own name. Then INDEX opens: every video, named.
     (Drag ONE .py onto RUN.bat to run only that one.)

THE SCRIPTS  (scripts\)
  pulse_cut.py    cuts between the takes on a rhythm:  RHYTHM = "x..x..x."
  crab_walk.py    one take, forward and back:          FORWARD = 3, BACK = 1
  velvet.py       stacks the takes:                    MODE = "mean"
  melt.py         redraws each frame (GPU, ~1 min):    PROMPT = "..."
  breathing_cut_made_by_a_chat.py   written by a chat, from one sentence

CHANGE ONE
  Open it in Notepad. The settings are at the top, in CAPITALS.
  Change a number or a word, save, double-click RUN.bat.

MAKE YOUR OWN
  Open scripts\FOR_THE_CHAT.txt and follow it. Three pastes and a sentence.

INDEX.bat   double-click it in any folder: every video in it, named, on one page.
legacy\     the older tools (one .bat each, recipe in a .txt). They still work.
