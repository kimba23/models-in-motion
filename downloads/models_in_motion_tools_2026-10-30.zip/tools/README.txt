TOOLS
=====

Everything you play with is in this folder. (_engine is the machinery: leave it.)

HOW IT WORKS
  1. A folder with the takes of ONE shot (the .mp4 files).
  2. Copy into it RUN.bat and the scripts you want (the .py files here).
  3. Double-click RUN.bat. Every .py in that folder that is new or changed runs
     (the others are skipped); each puts its result in a subfolder with its own
     name. Then INDEX opens: every video, named.
     (Drag ONE .py onto RUN.bat to run that one again, changed or not.)
     The sound follows the picture: each script leaves a .frames list (where
     every frame came from) and RUN rebuilds the audio from it.

THE SCRIPTS
  pulse_cut.py      the micro-edit (aspero): cuts between the takes on a rhythm
                    RHYTHM = "x..x..x."
  crab_walk.py      forward and back                 FORWARD = 3   BACK = 1
                    SALAD = "back": the steps back come from other takes
  velvet.py         stacks the takes                 MODE = "mean"
  melt.py           redraws each frame (GPU, ~1 min, close ComfyUI)   PROMPT = "..."
  breathing_cut.py  cuts more where it moves (written by a chat)
  the_random_thing.py  random cuts in 5/8, 7/8, 11/8, 13/8; each bar reads the
                    same backwards (Victor, with a chat)

CHANGE ONE
  Open it in Notepad. The settings are at the top, in CAPITALS.
  Change a number or a word, save, double-click RUN.bat.

MAKE YOUR OWN
  FOR_THE_CHAT.txt: paste its box into a chat, paste a script, write your idea.

INDEX.bat   double-click it in any folder: every video in it, named, on one page.
