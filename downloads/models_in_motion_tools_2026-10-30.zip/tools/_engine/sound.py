"""The sound for a script's video, rebuilt from its .frames list.

A script writes, next to name.mp4, a file name.frames: one line per frame of
its video, saying where that frame came from:

    12<TAB>take03.mp4                  frame 12 of take03
    12<TAB>take01.mp4<TAB>take02.mp4   frame 12 of these takes, mixed (velvet)

Here every output frame gets the 1/fps of a second of sound that belongs to
its source frame. When the source runs backwards (the crab stepping back), that
slice plays backwards too. Joins that jump get a 2 ms fade, so they don't click.
"""
import subprocess
from pathlib import Path

import imageio_ffmpeg
import numpy as np

RATE = 48000
FADE = 96                                    # samples: 2 ms at 48 kHz


def read_sound(video):
    """The whole soundtrack of a take as (samples, 2) floats, or None if it has none."""
    r = subprocess.run([imageio_ffmpeg.get_ffmpeg_exe(), "-loglevel", "error", "-i", str(video),
                        "-vn", "-f", "f32le", "-ac", "2", "-ar", str(RATE), "-"], capture_output=True)
    data = np.frombuffer(r.stdout, dtype=np.float32)
    return data.reshape(-1, 2) if data.size else None


def read_list(frames_file):
    rows = []
    for line in frames_file.read_text(encoding="utf-8").splitlines():
        parts = [p.strip() for p in line.split("\t") if p.strip()]
        if len(parts) >= 2 and parts[0].isdigit():
            rows.append((int(parts[0]), parts[1:]))
    return rows


def build(frames_file, fps, wav):
    """Write wav with the rebuilt sound. Returns False if the takes have no sound."""
    rows = read_list(frames_file)
    folder = frames_file.parent
    while folder != folder.parent and not any((folder / t).exists() for t in rows[0][1]):
        folder = folder.parent                  # the takes sit next to the script, above its results
    sounds = {}
    for _, takes in rows:
        for t in takes:
            if t not in sounds:
                sounds[t] = read_sound(folder / t)
    if not any(s is not None for s in sounds.values()):
        return False

    per = RATE / fps
    out, prev = [], None
    for i, (src, takes) in enumerate(rows):
        a, b = int(round(src * per)), int(round((src + 1) * per))
        pieces = []
        for t in takes:
            s = sounds[t]
            if s is not None:
                piece = s[a:b]
                pieces.append(np.pad(piece, ((0, (b - a) - len(piece)), (0, 0))))
        chunk = np.mean(pieces, axis=0) if pieces else np.zeros((b - a, 2), np.float32)
        if prev is not None and src < prev[0] and takes == prev[1]:
            chunk = chunk[::-1]                 # the picture goes back: so does the sound
        jump = prev is None or takes != prev[1] or src != prev[0] + 1
        if jump and len(chunk) > 2 * FADE:      # a soft edge where the sound jumps
            ramp = np.linspace(0, 1, FADE)[:, None]
            chunk = chunk.copy()
            chunk[:FADE] *= ramp
            if out:
                out[-1][-FADE:] *= ramp[::-1]
        out.append(chunk.astype(np.float32))
        prev = (src, takes)

    pcm = (np.clip(np.concatenate(out), -1, 1) * 32767).astype("<i2")
    import wave
    with wave.open(str(wav), "wb") as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(RATE)
        w.writeframes(pcm.tobytes())
    return True
