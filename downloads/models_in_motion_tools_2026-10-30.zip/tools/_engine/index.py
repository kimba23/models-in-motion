"""INDEX - every video in a folder (and its subfolders), on one page, with proper names.

Double-click INDEX.bat in a folder (or drag a folder onto it). It writes index.html
there and opens it: the takes first, then every result folder (aspero, velvet,
crab, your scripts ...), each video with its name and the recipe that made it.
Click a video to play it, F for full screen, arrows for the next one.
Run it again after new results.
"""
import html
import os
import json
import sys
import webbrowser
from pathlib import Path

VIDEO = {".mp4", ".webm", ".mov"}


def nice(name):
    """'02_tresillo' -> '02 tresillo', 'runner_00003_' -> 'runner 00003'"""
    return " ".join(name.replace("_", " ").replace("-", " ").split())


def scan(folder):
    groups = {}
    for p in sorted(folder.rglob("*")):
        rel = p.relative_to(folder)
        if p.suffix.lower() not in VIDEO or any(part.startswith(".") for part in rel.parts):
            continue
        group = "takes" if rel.parent == Path(".") else nice(str(rel.parent).replace("\\", " / "))
        txt = p.with_suffix(".txt")
        groups.setdefault(group, []).append({
            "src": rel.as_posix(), "title": nice(p.stem),
            "recipe": txt.read_text(encoding="utf-8", errors="replace") if txt.exists() else ""})
    order = sorted(groups, key=lambda g: (g != "takes", g))
    return [{"name": g, "videos": groups[g]} for g in order]


PAGE = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>__TITLE__</title>
<style>
  :root { --bg:#0b0b0c; --ink:#ece8e1; --dim:#8a857c; --hot:#ffcf3f; }
  * { box-sizing:border-box; }
  body { margin:0; background:var(--bg); color:var(--ink); font:16px/1.45 Georgia, serif; }
  header { padding:40px 24px 8px; max-width:1400px; margin:auto; }
  h1 { font-weight:normal; font-size:36px; margin:0; }
  header p { color:var(--dim); margin:4px 0 0; font:13px monospace; }
  main { max-width:1400px; margin:auto; padding:0 24px 100px; }
  h2 { font:13px/1 monospace; letter-spacing:.12em; text-transform:uppercase; color:var(--dim);
       margin:40px 0 12px; }
  .grid { display:grid; grid-template-columns:repeat(auto-fill, minmax(380px, 1fr)); gap:24px; }
  figure { margin:0; cursor:pointer; }
  video { width:100%; display:block; background:#000; aspect-ratio:16/9; object-fit:contain; }
  figcaption { display:flex; gap:12px; align-items:baseline; padding:6px 2px 0; }
  figcaption b { font-weight:normal; font-size:17px; flex:1; }
  figure.playing figcaption b { color:var(--hot); }
  button { background:none; border:1px solid #444; color:var(--dim); cursor:pointer; font:12px monospace;
           padding:3px 8px; border-radius:3px; }
  button:hover { color:var(--ink); border-color:var(--ink); }
  details { margin:4px 2px 0; color:var(--dim); font:12px/1.4 monospace; }
  details pre { white-space:pre-wrap; margin:6px 0 0; max-height:220px; overflow:auto; }
  .keys { position:fixed; right:16px; bottom:10px; color:#555; font:12px monospace; }
</style>
</head>
<body>
<header><h1>__TITLE__</h1><p>__COUNT__</p></header>
<main id="list"></main>
<div class="keys">click: play / stop · F: full screen · ↓ ↑: next / previous</div>
<script>
const GROUPS = __DATA__;
const list = document.getElementById("list"), figs = [];
for (const g of GROUPS) {
  const h = document.createElement("h2"); h.textContent = g.name; list.appendChild(h);
  const grid = document.createElement("div"); grid.className = "grid"; list.appendChild(grid);
  for (const v of g.videos) {
    const fig = document.createElement("figure");
    const video = document.createElement("video");
    video.src = v.src + "#t=0.5"; video.preload = "metadata"; video.playsInline = true;
    const cap = document.createElement("figcaption");
    cap.innerHTML = "<b></b><button>full screen</button>";
    cap.querySelector("b").textContent = v.title;
    cap.querySelector("button").onclick = e => { e.stopPropagation(); full(fig); };
    fig.append(video, cap);
    if (v.recipe) {
      const d = document.createElement("details");
      d.innerHTML = "<summary>how it was made</summary><pre></pre>";
      d.querySelector("pre").textContent = v.recipe;
      d.onclick = e => e.stopPropagation();
      fig.append(d);
    }
    fig.onclick = () => toggle(fig);
    fig.ondblclick = () => full(fig);
    video.onended = () => fig.classList.remove("playing");
    grid.appendChild(fig); figs.push(fig);
  }
}
let current = null;
function toggle(fig) {
  const video = fig.querySelector("video");
  if (!video.paused) { video.pause(); fig.classList.remove("playing"); return; }
  for (const f of figs) if (f !== fig) { f.querySelector("video").pause(); f.classList.remove("playing"); }
  video.play(); fig.classList.add("playing"); current = fig;
  if (document.fullscreenElement && document.fullscreenElement !== video) video.requestFullscreen();
  else fig.scrollIntoView({ behavior: "smooth", block: "nearest" });
}
function full(fig) {
  fig.querySelector("video").requestFullscreen?.();
  if (fig.querySelector("video").paused) toggle(fig);
}
document.addEventListener("keydown", e => {
  const i = figs.indexOf(current);
  if (e.key === " ") { e.preventDefault(); toggle(current || figs[0]); }
  if (e.key === "f" || e.key === "F") {
    if (document.fullscreenElement) document.exitFullscreen(); else full(current || figs[0]);
  }
  if (e.key === "ArrowDown" || e.key === "ArrowRight") { e.preventDefault(); toggle(figs[Math.min(i + 1, figs.length - 1)]); }
  if (e.key === "ArrowUp" || e.key === "ArrowLeft") { e.preventDefault(); toggle(figs[Math.max(i - 1, 0)]); }
});
</script>
</body>
</html>
"""


def main():
    t = Path(sys.argv[1]) if len(sys.argv) > 1 else Path.cwd()
    folder = (t.parent if t.is_file() else t).resolve()
    groups = scan(folder)
    n = sum(len(g["videos"]) for g in groups)
    page = (PAGE.replace("__TITLE__", html.escape(nice(folder.name)))
                .replace("__COUNT__", f"{n} videos in {len(groups)} folders")
                .replace("__DATA__", json.dumps(groups, ensure_ascii=False).replace("</", "<\\/")))
    out = folder / "index.html"
    out.write_text(page, encoding="utf-8")
    print(f"{n} videos in {len(groups)} folders -> {out}")
    if "--no-open" not in sys.argv and not os.environ.get("NO_OPEN"):
        webbrowser.open(out.as_uri())


main()
