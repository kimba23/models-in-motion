"""RUN - plays every script in a folder of takes, then opens INDEX.

The scripts can come from anywhere: the kit, a classmate, a chat. RUN only
asks that they are .py files sitting in the folder of takes. Afterwards it
makes every new video playable in the browser (chats usually write mp4v,
which browsers refuse), and writes index.html: every video, with its name.

Double-click RUN.bat in the folder: every .py there that is new or changed since its last result runs.
Drag one .py onto RUN.bat: only that one runs, changed or not.
"""
import hashlib
import subprocess
import sys
import time
from pathlib import Path
import imageio_ffmpeg
from sound import build as sound_rebuild

KIT = Path(__file__).resolve().parents[2]
PYTHON = Path(sys.executable)
VIDEO = {".mp4", ".avi", ".mov", ".mkv", ".webm"}


def playable(video):
    """Re-encode to H.264 mp4, the one format every browser plays.
    If the script left a .frames list beside the video, the sound is rebuilt from it."""
    ffmpeg = imageio_ffmpeg.get_ffmpeg_exe()
    out = video.with_suffix(".mp4")
    tmp = video.with_name(video.stem + ".__tmp.mp4")
    wav = video.with_name(video.stem + ".__tmp.wav")
    sound = []
    frames = video.with_suffix(".frames")
    if frames.exists():
        import cv2
        fps = cv2.VideoCapture(str(video)).get(cv2.CAP_PROP_FPS) or 24
        try:
            if sound_rebuild(frames, fps, wav):
                sound = ["-i", str(wav), "-map", "0:v", "-map", "1:a", "-shortest"]
        except Exception as e:
            print(f"   no sound for {video.name}: {e}")
    r = subprocess.run([ffmpeg, "-y", "-loglevel", "error", "-i", str(video), *sound, "-c:v", "libx264",
                        "-pix_fmt", "yuv420p", "-crf", "18", "-c:a", "aac", "-b:a", "192k", str(tmp)])
    wav.unlink(missing_ok=True)
    if r.returncode or not tmp.exists():
        print(f"   could not convert {video.name}")
        return
    if video != out:
        video.unlink()
    tmp.replace(out)


def fingerprint(script):
    return hashlib.sha1(script.read_bytes()).hexdigest()


def changed_since_last_result(script):
    """True if the script has no results yet, or its text is different from the last run
    (compares the content, not the date: a copied file keeps its old date)."""
    mark = script.parent / script.stem / ".last_run"
    return not mark.exists() or mark.read_text().strip() != fingerprint(script)


def main():
    arg = Path(sys.argv[1]) if len(sys.argv) > 1 else Path.cwd()
    folder = arg.parent if arg.is_file() else arg
    scripts = [arg] if arg.suffix.lower() == ".py" else sorted(folder.glob("*.py"))
    if not scripts:
        print(f"No .py files in {folder}")
        print("Save a script from the chat into this folder (as name.py, not name.py.txt).")
        return
    for s in folder.glob("*.py.txt"):
        print(f"! {s.name} is a text file: rename it to {s.name[:-4]} so it can run")

    started = time.time() - 1
    forced = arg.suffix.lower() == ".py"
    for script in scripts:
        if not forced and not changed_since_last_result(script):
            print(f"\n=== {script.name}: no changes since its last result, skipped "
                  f"(drag it onto RUN.bat to run it again)", flush=True)
            continue
        print(f"\n=== {script.name} ===", flush=True)
        r = subprocess.run([str(PYTHON), "-s", str(script)], cwd=str(folder))
        results = folder / script.stem
        if r.returncode == 0 and results.is_dir():
            (results / ".last_run").write_text(fingerprint(script))
        if r.returncode:
            print(f"\n{script.name} STOPPED WITH AN ERROR.")
            print("Copy everything above, paste it to the chat, and ask it to fix the script.")

    new = [p for p in folder.rglob("*") if p.suffix.lower() in VIDEO and p.parent != folder
           and p.stat().st_mtime >= started and ".__tmp" not in p.name]
    if new:
        print(f"\nmaking {len(new)} new video(s) playable in the browser ...", flush=True)
        for v in new:
            playable(v)

    subprocess.run([str(PYTHON), "-s", str(KIT / "tools" / "_engine" / "index.py"), str(folder)])


main()
