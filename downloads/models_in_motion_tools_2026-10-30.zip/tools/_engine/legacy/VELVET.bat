@echo off
:: VELVET - stack the takes. Recipe velvet.txt, results in velvet\
:: Use it either way:
::   - copy this file into a folder of takes and double-click it, or
::   - drag a folder (or a video) onto it.
setlocal
set "KIT="
rem 1. the kit is right here (this file is in the kit's tools folder)
if exist "%~dp0..\..\..\python\python.exe" for %%I in ("%~dp0..\..\..") do set "KIT=%%~fI"
rem 2. otherwise, the note the kit leaves when it runs
if not defined KIT if exist "%USERPROFILE%\models_in_motion_location.txt" set /p KIT=<"%USERPROFILE%\models_in_motion_location.txt"
if not defined KIT goto nokit
if not exist "%KIT%\python\python.exe" goto nokit
rem remember where the kit is, so copies of this file can find it
> "%USERPROFILE%\models_in_motion_location.txt" echo %KIT%
set "TARGET=%~1"
if "%TARGET%"=="" set "TARGET=%~dp0."
set PYTHONNOUSERSITE=1
set PYTHONIOENCODING=utf-8
"%KIT%\python\python.exe" -s "%KIT%\tools\_engine\velvet.py" "%TARGET%"
pause
exit /b
:nokit
echo Cannot find the Models in Motion kit.
echo Run START.bat (or CHECK.bat) in the kit folder once, then try again.
pause
